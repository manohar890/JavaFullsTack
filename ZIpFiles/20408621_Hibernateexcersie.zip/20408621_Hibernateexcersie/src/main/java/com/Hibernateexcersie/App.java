package com.Hibernateexcersie;



import java.text.ParseException;


/**
 * Hello world!
 *
 */
public class App{
	public static void main(String []args) throws ParseException {
		EmployeeDao Dao = new EmployeeDao();
		Dao.options();
		
	}
}