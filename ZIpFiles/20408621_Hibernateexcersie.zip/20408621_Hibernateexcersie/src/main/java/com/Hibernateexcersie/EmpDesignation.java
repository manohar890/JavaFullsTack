package com.Hibernateexcersie;

public enum EmpDesignation {
	SE, SSE, SS, SSS;
}
