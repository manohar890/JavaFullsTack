package com.springL2.assignment3.mode;

public class Marks {
	
	private int science;
	private int mathematics;
	private int english;
	
	public Marks() {}
	
	
	

	public Marks(int science, int mathematics, int english) {
		super();
		this.science = science;
		this.mathematics = mathematics;
		this.english = english;
	}




	public int getScience() {
		return science;
	}

	public void setScience(int science) {
		this.science = science;
	}

	public int getMathematics() {
		return mathematics;
	}

	public void setMathematics(int mathematics) {
		this.mathematics = mathematics;
	}

	public int getEnglish() {
		return english;
	}

	public void setEnglish(int english) {
		this.english = english;
	}
	
	
	
	
}