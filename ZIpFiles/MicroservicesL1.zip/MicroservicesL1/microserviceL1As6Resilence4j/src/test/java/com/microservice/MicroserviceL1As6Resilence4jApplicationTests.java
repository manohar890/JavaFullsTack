package com.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceL1As6Resilence4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
