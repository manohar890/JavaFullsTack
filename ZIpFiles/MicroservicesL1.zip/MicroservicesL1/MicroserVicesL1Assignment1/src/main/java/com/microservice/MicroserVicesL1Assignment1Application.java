package com.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserVicesL1Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(MicroserVicesL1Assignment1Application.class, args);
	}

}
