package com.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceL1As3ServiceProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceL1As3ServiceProducerApplication.class, args);
	}

}
